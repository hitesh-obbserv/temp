# -*- coding: utf-8 -*-
# @Date    : 13-01-2022
# @Author  : Hitesh Gorana
# @Link    : None
# @Version : 0.0
import os
import io
import datetime
import uuid


async def get_filename():
    today_date = datetime.datetime.now()
    filename = datetime.datetime.strftime(today_date, '%Y-%m%d-%H-%M-%S') + ".csv"
    return filename


async def create_download_links(data, filename, name):
    os.makedirs("data/" + name, exist_ok=True)
    data.to_csv("data/" + name + "/" + filename + ".csv", index=False)
    return f"http://165.232.188.26/download/{name}/{filename}.csv"


async def unique_id():
    return "".join(str(uuid.uuid4()).split("-"))


async def dataframe_to_stream(data):
    stream = io.StringIO()
    data.to_csv(stream)
    return stream
