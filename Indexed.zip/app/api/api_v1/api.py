# -*- coding: utf-8 -*-
# @Date    : 12-01-2022
# @Author  : Hitesh Gorana
# @Link    : None
# @Version : 0.0
from fastapi import APIRouter

from app.api.api_v1.endpoints import Google_Index

api_router = APIRouter()
api_router.include_router(Google_Index.router)
