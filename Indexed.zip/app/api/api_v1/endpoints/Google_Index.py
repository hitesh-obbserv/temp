# -*- coding: utf-8 -*-
# @Date    : 12-01-2022
# @Author  : Hitesh Gorana
# @Link    : None
# @Version : 0.0
import time

from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
import pandas as pd
from starlette.responses import StreamingResponse

from app.utils.download_utility import dataframe_to_stream, get_filename, unique_id, create_download_links
from app.utils.google import search
from app.utils.url import url_validate

router = APIRouter()

templates = Jinja2Templates(directory="templates")


@router.get("/download/{name}/{filename}")
async def download(name, filename):
    data = pd.read_csv(f"data/{name}/{filename}")
    stream = await dataframe_to_stream(data)
    response = StreamingResponse(iter([stream.getvalue()]),
                                 media_type="text/csv"
                                 )
    file_name = await get_filename()
    response.headers["Content-Disposition"] = f"attachment; filename={file_name}"
    return response


@router.post("/index")
async def func_google(request: Request):
    form = await request.form()
    urls = str(form.get("urls")).strip()
    output = []
    link = ""
    if urls:
        urls = [i.strip() for i in urls.split('\n') if i]
        for url in set(urls):
            time.sleep(2)
            response = dict(
                url=url,
                index=("indexed" if search(url) else "not indexed") if url_validate(url) else "not indexed"
            )
            output.append(response)
        filename = await unique_id()
        name = await unique_id()
        link = await create_download_links(pd.DataFrame(output), filename, name)
    if output:
        return templates.TemplateResponse("tabel.html",
                                          {"request": request, "items": output, "link": link})
    else:
        return templates.TemplateResponse("index.html", {"request": request})


@router.get("/")
async def read_he_item(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
